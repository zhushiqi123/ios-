//
//  EAEditCodeReleaseViewController.h
//  Coding_iOS
//
//  Created by Easeeeeeeeee on 2018/3/27.
//  Copyright © 2018年 Coding. All rights reserved.
//

#import "BaseViewController.h"
#import "EACodeRelease.h"

@interface EAEditCodeReleaseViewController : BaseViewController
@property (strong, nonatomic) EACodeRelease *curR;

@end
