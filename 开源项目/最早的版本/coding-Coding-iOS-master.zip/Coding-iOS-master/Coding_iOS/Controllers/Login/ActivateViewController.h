//
//  ActivateViewController.h
//  Coding_iOS
//
//  Created by Ease on 16/2/18.
//  Copyright © 2016年 Coding. All rights reserved.
//

#import "BaseViewController.h"

@interface ActivateViewController : BaseViewController

@end
