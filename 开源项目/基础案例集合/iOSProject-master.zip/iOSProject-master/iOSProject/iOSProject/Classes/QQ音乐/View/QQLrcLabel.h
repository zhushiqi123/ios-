//
//  QQLrcLabel.h
//  QQMusic
//
//  Created by Apple on 16/5/18.
//  Copyright © 2016年 KeenLeung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QQLrcLabel : UILabel

@property (nonatomic, assign) CGFloat progress;

@end
