//
//  LMJMessageViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/4/6.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJStaticTableViewController.h"

@interface LMJMessageViewController : LMJStaticTableViewController

@end
