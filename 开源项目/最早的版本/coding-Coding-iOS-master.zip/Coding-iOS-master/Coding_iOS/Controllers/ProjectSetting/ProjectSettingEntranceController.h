//
//  ProjectSettingEntranceController.h
//  Coding_iOS
//
//  Created by Easeeeeeeeee on 2018/4/25.
//  Copyright © 2018年 Coding. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Project.h"

@interface ProjectSettingEntranceController : UITableViewController

@property (nonatomic, strong) Project *project;

@end
