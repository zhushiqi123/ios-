#include "iostream.h"
#include "stdio.h"
void print(); //��������
void main()
{ int i;
 char s[10];
 print( );
 cout<<"What's your name?\n"; 
 cin>>s;
 cout<<"How old are you?\n";
 cin>>i;
 cout<<s<<" is "<<i<<" years old.";
 print( );
 }
void print( )
{
printf("printf is also can be used\n");
}

