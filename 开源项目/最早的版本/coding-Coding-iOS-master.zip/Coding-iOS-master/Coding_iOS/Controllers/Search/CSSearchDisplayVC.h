//
//  CSSearchDisplayVC.h
//  Coding_iOS
//
//  Created by pan Shiyu on 15/7/14.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CSSearchDisplayVC : UISearchDisplayController {

}
@property (nonatomic,weak)UIViewController *parentVC;

@end
