//
//  ProjectDeleteAlertControllerVisualStyle.h
//  Coding_iOS
//
//  Created by isaced on 15/4/1.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import "SDCAlertControllerDefaultVisualStyle.h"

@interface ProjectDeleteAlertControllerVisualStyle : SDCAlertControllerDefaultVisualStyle

@end
