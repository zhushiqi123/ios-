//
//  LMJRunLoopViewController.h
//  iOSProject
//
//  Created by HuXuPeng on 2018/2/8.
//  Copyright © 2018年 github.com/njhu. All rights reserved.
//

#import "LMJStaticTableViewController.h"

@interface LMJRunLoopViewController : LMJStaticTableViewController

@end
