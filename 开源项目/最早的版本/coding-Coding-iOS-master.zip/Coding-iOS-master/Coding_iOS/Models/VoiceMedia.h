//
//  VoiceMedia.h
//  Coding_iOS
//
//  Created by sumeng on 8/2/15.
//  Copyright (c) 2015 Coding. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VoiceMedia : NSObject

@property (nonatomic, strong) NSString *file;
@property (nonatomic, assign) NSTimeInterval duration;

@end
