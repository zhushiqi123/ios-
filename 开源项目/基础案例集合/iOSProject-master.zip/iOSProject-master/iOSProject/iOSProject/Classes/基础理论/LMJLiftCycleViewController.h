//
//  LMJLiftCycleViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/4/13.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJStaticTableViewController.h"

@interface LMJLiftCycleViewController : LMJStaticTableViewController

@end
