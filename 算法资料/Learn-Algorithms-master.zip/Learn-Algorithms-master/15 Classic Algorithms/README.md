
## 15个经典基础算法


* A*寻路算法 ：求解最短路径 
* Dijkstra：最短路径算法 
>Dijkstra是荷兰的计算机科学家,提出”信号量和PV原语“,"解决哲学家就餐问题",”死锁“也是它提出来的

* 动态规划 (Dynamic Programming)
* BFS/DFS （广度/深度优先遍历）    
* 红黑树  一种自平衡的`二叉查找树`
* KMP    字符串匹配算法   
* 遗传算法  
* 启发式搜索   
* 图像特征提取之SIFT算法  
* 傅立叶变换  
* Hash  
* 快速排序  
* SPFA(shortest path faster algorithm) 单元最短路径算法  
* 快递选择SELECT  

