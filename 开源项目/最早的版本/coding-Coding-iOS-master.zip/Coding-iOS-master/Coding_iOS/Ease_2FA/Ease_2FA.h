//
//  Ease_2FA.h
//  Coding_iOS
//
//  Created by Ease on 15/7/2.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#ifndef Coding_iOS_Ease_2FA_h
#define Coding_iOS_Ease_2FA_h

#import "OTPListViewController.h"


#endif
