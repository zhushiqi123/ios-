//
//  UserInfoDetailViewController.h
//  Coding_iOS
//
//  Created by Ease on 15/3/19.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import "BaseViewController.h"
#import "User.h"

@interface UserInfoDetailViewController : BaseViewController
@property (strong, nonatomic) User *curUser;

@end
