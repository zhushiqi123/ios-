//
//  SINDiscoveryViewController.m
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/5/11.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "SINDiscoveryViewController.h"

@interface SINDiscoveryViewController ()

@end

@implementation SINDiscoveryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"发现";
}

@end
