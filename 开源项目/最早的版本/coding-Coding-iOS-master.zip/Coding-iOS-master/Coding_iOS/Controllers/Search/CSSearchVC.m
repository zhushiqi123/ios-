//
//  SearchVC.m
//  Coding_iOS
//
//  Created by pan Shiyu on 15/7/13.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import "CSSearchVC.h"

@interface CSSearchVC ()

@end

@implementation CSSearchVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

@end

@implementation CSBarButtonItem

- (void)updateBadgeValueAnimated:(BOOL)animated
{
    NSLog(@"");
}

@end
