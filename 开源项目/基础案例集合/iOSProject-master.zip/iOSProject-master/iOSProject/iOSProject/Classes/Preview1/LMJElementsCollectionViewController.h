//
//  LMJElementsCollectionViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/4/19.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJCollectionViewController.h"

@interface LMJElementsCollectionViewController : LMJCollectionViewController

@end
