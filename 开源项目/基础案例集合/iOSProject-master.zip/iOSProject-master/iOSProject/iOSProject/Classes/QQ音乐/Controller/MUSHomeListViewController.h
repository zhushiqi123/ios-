//
//  MUSHomeListViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/9/26.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJStaticTableViewController.h"

@interface MUSHomeListViewController : LMJTableViewController

@end
