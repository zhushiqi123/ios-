//
//  SearchVC.h
//  Coding_iOS
//
//  Created by pan Shiyu on 15/7/13.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CSSearchModel.h"

@interface CSSearchVC : BaseViewController

@end

//
@interface CSBarButtonItem : UIBarButtonItem
@property (nonatomic,assign) BOOL showBadge;
@end
