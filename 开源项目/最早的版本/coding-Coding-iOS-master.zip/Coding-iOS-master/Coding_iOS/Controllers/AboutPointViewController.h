//
//  AboutPointViewController.h
//  Coding_iOS
//
//  Created by Easeeeeeeeee on 2017/9/18.
//  Copyright © 2017年 Coding. All rights reserved.
//

#import "BaseViewController.h"

@interface AboutPointViewController : BaseViewController

@end
