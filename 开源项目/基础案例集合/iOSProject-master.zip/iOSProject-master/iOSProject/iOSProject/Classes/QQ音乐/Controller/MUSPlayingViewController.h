//
//  MUSPlayingViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/9/28.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJBaseViewController.h"

@interface MUSPlayingViewController : LMJBaseViewController

@end
