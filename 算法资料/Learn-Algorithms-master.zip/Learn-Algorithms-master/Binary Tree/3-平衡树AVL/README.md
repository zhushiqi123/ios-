
### AVL 实现过程中的问题



### AVL 实际使用案例

 * LLVM 的 ImmutableSet，其底层的实现选择为 AVL 树
 * 《一种基于二叉平衡树的P2P覆盖网络的研究》论文