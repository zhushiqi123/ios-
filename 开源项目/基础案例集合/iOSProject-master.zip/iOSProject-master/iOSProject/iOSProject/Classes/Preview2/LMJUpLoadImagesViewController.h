//
//  LMJUpLoadImagesViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/5/4.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJCollectionViewController.h"

@interface LMJUpLoadImagesViewController : LMJCollectionViewController

@end
