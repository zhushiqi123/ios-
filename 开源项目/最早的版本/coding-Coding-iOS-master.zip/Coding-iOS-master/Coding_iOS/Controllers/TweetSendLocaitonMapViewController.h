//
//  TweetSendLocaitonMapViewController.h
//  Coding_iOS
//
//  Created by Kevin on 3/16/15.
//  Copyright (c) 2015 Coding. All rights reserved.
//

#import "BaseViewController.h"
@class Tweet;

@interface TweetSendLocaitonMapViewController : BaseViewController

@property(nonatomic,strong) Tweet *tweet;
@end
