//
//  MCStudent+CoreDataClass.h
//  
//
//  Created by HuXuPeng on 2018/5/3.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface MCStudent : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "MCStudent+CoreDataProperties.h"
