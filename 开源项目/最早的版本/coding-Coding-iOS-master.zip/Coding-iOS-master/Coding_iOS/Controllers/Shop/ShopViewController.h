//
//  ShopViewController.h
//  Coding_iOS 商城界面
//
//  Created by liaoyp on 15/11/20.
//  Copyright © 2015年 Coding. All rights reserved.
//

#import "BaseViewController.h"

@interface ShopViewController : BaseViewController

@end

