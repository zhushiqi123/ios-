//
//  LMJNavigationController.h
//  PLMMPRJK
//
//  Created by NJHu on 2017/3/31.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import <UIKit/UIKit.h>
#include <UINavigationController+FDFullscreenPopGesture.h>

@interface LMJNavigationController : UINavigationController

@end
