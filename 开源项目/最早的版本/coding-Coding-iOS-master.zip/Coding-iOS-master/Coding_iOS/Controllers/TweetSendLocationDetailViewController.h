//
//  TweetSendLocationDetailViewController.h
//  Coding_iOS
//
//  Created by Kevin on 3/15/15.
//  Copyright (c) 2015 Coding. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Tweet;

@interface TweetSendLocationDetailViewController : UITableViewController

@property(nonatomic,strong) Tweet *tweet;

@end
