//
//  LMJH5JSBridgeViewController.h
//  iOSProject
//
//  Created by HuXuPeng on 2018/3/17.
//  Copyright © 2018年 github.com/njhu. All rights reserved.
//

#import "LMJWebViewController.h"

@interface LMJH5JSBridgeViewController : LMJWebViewController

@end
