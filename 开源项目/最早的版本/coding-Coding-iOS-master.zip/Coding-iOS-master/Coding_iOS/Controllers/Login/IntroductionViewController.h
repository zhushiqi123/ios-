//
//  IntroductionViewController.h
//  Coding_iOS
//
//  Created by Ease on 15/6/24.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import <IFTTTJazzHands.h>

@interface IntroductionViewController : IFTTTAnimatedPagingScrollViewController

@end
