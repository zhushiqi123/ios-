//
//  LMJOfflineDownloadViewController.h
//  iOSProject
//
//  Created by HuXuPeng on 2018/2/26.
//  Copyright © 2018年 github.com/njhu. All rights reserved.
//

#import "LMJStaticTableViewController.h"

@interface LMJOfflineDownloadViewController : LMJStaticTableViewController

@end
