//
//  MeDisplayViewController.h
//  Coding_iOS
//
//  Created by Ease on 2016/9/9.
//  Copyright © 2016年 Coding. All rights reserved.
//

#import "UserOrProjectTweetsViewController.h"

@interface MeDisplayViewController : UserOrProjectTweetsViewController

@end
