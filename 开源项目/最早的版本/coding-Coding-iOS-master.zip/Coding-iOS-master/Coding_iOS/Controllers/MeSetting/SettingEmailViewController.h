//
//  SettingEmailViewController.h
//  Coding_iOS
//
//  Created by Ease on 16/5/23.
//  Copyright © 2016年 Coding. All rights reserved.
//

#import "BaseViewController.h"

@interface SettingEmailViewController : BaseViewController

@end
