//
//  SINHomeViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/5/11.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJRefreshTableViewController.h"
#import "SIN.h"

@interface SINHomeViewController : LMJRefreshTableViewController

@end
