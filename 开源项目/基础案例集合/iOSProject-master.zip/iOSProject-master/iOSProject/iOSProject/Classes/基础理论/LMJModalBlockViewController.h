//
//  LMJModalBlockViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/4/17.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJBaseViewController.h"

@interface LMJModalBlockViewController : LMJBaseViewController

@property(nonatomic,copy) void(^successBlock)(void);

@end
