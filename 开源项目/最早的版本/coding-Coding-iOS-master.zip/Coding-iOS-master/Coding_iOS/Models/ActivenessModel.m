//
//  ActivenessModel.m
//  Coding_iOS
//
//  Created by 张达棣 on 16/11/29.
//  Copyright © 2016年 Coding. All rights reserved.
//

#import "ActivenessModel.h"

@implementation ActivenessModel

@end


@implementation ActiveDuration

@end

@implementation DailyActiveness

@end
