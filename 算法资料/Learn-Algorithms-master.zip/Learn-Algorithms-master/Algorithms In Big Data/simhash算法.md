
## simhash算法
