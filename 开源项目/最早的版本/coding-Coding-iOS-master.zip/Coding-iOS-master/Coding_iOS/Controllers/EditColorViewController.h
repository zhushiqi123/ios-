//
//  EditColorViewController.h
//  Coding_iOS
//
//  Created by Ease on 16/2/19.
//  Copyright © 2016年 Coding. All rights reserved.
//

#import "BaseViewController.h"
#import "ProjectTag.h"

@interface EditColorViewController : BaseViewController
@property (strong, nonatomic) ProjectTag *curTag;
@end
