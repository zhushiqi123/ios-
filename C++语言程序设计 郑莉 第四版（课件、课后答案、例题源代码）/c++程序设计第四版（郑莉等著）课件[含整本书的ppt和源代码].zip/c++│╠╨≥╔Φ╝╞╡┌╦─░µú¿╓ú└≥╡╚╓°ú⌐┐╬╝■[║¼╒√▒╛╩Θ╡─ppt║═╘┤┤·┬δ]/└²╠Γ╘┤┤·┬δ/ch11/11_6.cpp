//11_6.cpp
#include <iostream>
using namespace std;
void main()
{
    char ch;
    while ((ch=cin.get())!=EOF)
         cout.put(ch);
}

