//
//  LMJCuteFlowLayoutViewController.h
//  iOSProject
//
//  Created by HuXuPeng on 2018/3/18.
//  Copyright © 2018年 github.com/njhu. All rights reserved.
//

#import "LMJCollectionViewController.h"

@interface LMJCuteFlowLayoutViewController : LMJCollectionViewController

@end
