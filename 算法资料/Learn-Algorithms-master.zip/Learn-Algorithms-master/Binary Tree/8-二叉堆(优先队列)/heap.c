



void heap_build(int *a,int length){


}


// 插入
void heap_insert(int *a,int v){



}


//删除,删除的元素放在value指向的内存中
void heap_delete(int *a,int *value){


}




