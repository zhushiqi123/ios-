//
//  ProjectServiceInfo.h
//  Coding_iOS
//
//  Created by Ease on 2016/9/19.
//  Copyright © 2016年 Coding. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProjectServiceInfo : NSObject
@property (strong, nonatomic) NSNumber *max_member, *git_memory, *used_day, *member, *max_git_memory;
@end
