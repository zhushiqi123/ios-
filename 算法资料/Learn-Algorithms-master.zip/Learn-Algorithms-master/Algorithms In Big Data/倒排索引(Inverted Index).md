
## 倒排索引(Inverted Index)

也叫反向索引。是文档检索系统中最常用的数据结构。常规的索引是文档到关键词的映射，如果对应的文档是



[Elasticsearch](https://github.com/elastic/elasticsearch)就是使用倒排索引(inverted index)的结构来做快速的全文搜索。ElasticSearch 不仅用于全文搜索, 还有非常强大的统计功能 (facets)。

携程，58，美团的分享中都提到ES构建实时日志系统，帮助定位系统问题。


[Elasticsearch权威指南](http://es.xiaoleilu.com/index.html)


