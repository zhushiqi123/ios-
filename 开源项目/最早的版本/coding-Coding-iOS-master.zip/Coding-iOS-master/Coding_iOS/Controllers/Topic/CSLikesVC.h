//
//  CSLikesVC.h
//  Coding_iOS
//
//  Created by pan Shiyu on 15/7/27.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import "LikersViewController.h"

@interface CSLikesVC : BaseViewController<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic,assign)int topicID;
@end
