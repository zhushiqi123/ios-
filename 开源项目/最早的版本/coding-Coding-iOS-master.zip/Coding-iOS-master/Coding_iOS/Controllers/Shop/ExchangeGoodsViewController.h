//
//  ExchangeGoodsViewController.h
//  Coding_iOS
//
//  Created by liaoyp on 15/11/20.
//  Copyright © 2015年 Coding. All rights reserved.
//

#import "BaseViewController.h"
#import "ShopGoods.h"

@interface ExchangeGoodsViewController : BaseViewController

@property(nonatomic , strong)ShopGoods *shopGoods;

@end
