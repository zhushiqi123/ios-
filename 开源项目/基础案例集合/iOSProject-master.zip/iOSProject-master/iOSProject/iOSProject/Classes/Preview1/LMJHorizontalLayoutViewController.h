//
//  LMJHorizontalLayoutViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/4/20.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJCollectionViewController.h"

@interface LMJHorizontalLayoutViewController : LMJCollectionViewController

@end
