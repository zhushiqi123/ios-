//
//  LMJFillTableFormViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/5/6.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJStaticTableViewController.h"

@interface LMJFillTableFormViewController : LMJStaticTableViewController

@end
