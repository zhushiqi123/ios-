//
//  LMJExpandImageView.h
//  GoMeYWLC
//
//  Created by NJHu on 2016/11/10.
//  Copyright © 2016年 NJHu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMJExpandImageView : UIImageView

@end
