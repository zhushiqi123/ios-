//9_9.cpp
#include "9_9.h"
void main(void)
{
    Calculator CALC;
    CALC.Run();
}
