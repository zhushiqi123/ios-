//
//  CodeBranchOrTag.m
//  Coding_iOS
//
//  Created by Ease on 15/1/30.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import "CodeBranchOrTag.h"

@implementation CodeBranchOrTag



@end


@implementation CodeBranchOrTagCommit

@end

@implementation CodeBranchOrTagMetric

@end
