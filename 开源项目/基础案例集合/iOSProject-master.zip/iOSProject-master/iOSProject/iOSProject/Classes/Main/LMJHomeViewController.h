//
//  LMJHomeViewController.h
//  PLMMPRJK
//
//  Created by NJHu on 2017/3/29.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJStaticTableViewController.h"

@interface LMJHomeViewController : LMJStaticTableViewController

@end
