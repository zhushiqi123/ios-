//
//  DashesLineView.h
//  BanTang
//
//  Created by liaoyp on 15/10/16.
//  Copyright © 2015年 JiuZhouYunDong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashesLineView : UIView

@property(nonatomic,strong)UIColor* lineColor;//虚线颜色



@end
