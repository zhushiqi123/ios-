//
//  LMJUpLoadProgressViewController.h
//  iOSProject
//
//  Created by HuXuPeng on 2017/12/31.
//  Copyright © 2017年 HuXuPeng. All rights reserved.
//

#import "LMJCollectionViewController.h"

@interface LMJUpLoadProgressViewController : LMJCollectionViewController

@end
