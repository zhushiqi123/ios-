//
//  LMJWordArrowItem.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/4/11.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LMJWordItem.h"

@interface LMJWordArrowItem : LMJWordItem

/** <#digest#> */
@property (assign, nonatomic) Class destVc;

@end
