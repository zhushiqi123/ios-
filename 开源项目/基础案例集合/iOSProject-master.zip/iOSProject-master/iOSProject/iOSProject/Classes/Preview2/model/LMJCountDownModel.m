//
//  LMJCountDownModel.m
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/5/5.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJCountDownModel.h"
@interface LMJCountDownModel()

@end

@implementation LMJCountDownModel


- (void)dealloc {

}

@end
