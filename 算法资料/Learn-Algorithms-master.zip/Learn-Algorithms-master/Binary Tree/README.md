
* 二叉查找树
* 赫夫曼编码 Huffman
* 字典树trie(前缀树，单词查找树)
* 伸展树
* 后缀树

* AVL树
* 红黑树

* B树
* B+树   mysql索引使用B+树的数据结构
* B*树
* R树
* Treap 树









