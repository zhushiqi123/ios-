//
//  PublicSearchModel.m
//  Coding_iOS
//
//  Created by jwill on 15/11/19.
//  Copyright © 2015年 Coding. All rights reserved.
//

#import "PublicSearchModel.h"

@implementation PublicSearchModel

@end
