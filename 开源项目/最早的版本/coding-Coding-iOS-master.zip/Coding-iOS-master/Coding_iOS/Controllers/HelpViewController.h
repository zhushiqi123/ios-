//
//  HelpViewController.h
//  Coding_iOS
//
//  Created by Ease on 2016/9/8.
//  Copyright © 2016年 Coding. All rights reserved.
//

#import "WebViewController.h"

@interface HelpViewController : WebViewController
+ (instancetype)vcWithHelpStr;
@end
