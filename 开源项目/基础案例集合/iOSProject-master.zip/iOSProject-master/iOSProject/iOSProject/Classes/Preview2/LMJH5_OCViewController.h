//
//  LMJH5_OCViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/5/5.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJWebViewController.h"

@interface LMJH5_OCViewController : LMJWebViewController

@end
