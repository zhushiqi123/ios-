//
//  NProjectViewController.h
//  Coding_iOS
//
//  Created by Ease on 15/3/11.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import "BaseViewController.h"
#import "Projects.h"

@interface NProjectViewController : BaseViewController
@property (nonatomic, strong) Project *myProject;

- (void)cloneRepo;

@end
