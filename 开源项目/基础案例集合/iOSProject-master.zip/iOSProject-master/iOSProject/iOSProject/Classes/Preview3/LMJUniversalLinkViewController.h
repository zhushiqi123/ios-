//
//  LMJUniversalLinkViewController.h
//  iOSProject
//
//  Created by HuXuPeng on 2018/5/5.
//  Copyright © 2018年 github.com/njhu. All rights reserved.
//

#import "LMJWebViewController.h"

@interface LMJUniversalLinkViewController : LMJWebViewController

@end
