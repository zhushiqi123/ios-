//
//  BaseNavigationController.h
//  Coding_iOS
//
//  Created by Ease on 15/2/5.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNavigationController : UINavigationController
- (void)hideNavBottomLine;
- (void)showNavBottomLine;
@end
