//
//  SettingPhoneViewController.h
//  Coding_iOS
//
//  Created by Ease on 15/12/28.
//  Copyright © 2015年 Coding. All rights reserved.
//

#import "BaseViewController.h"
#import "User.h"

@interface SettingPhoneViewController : BaseViewController

@end
