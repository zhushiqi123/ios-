//
//  LMJMasonryViewController.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/4/29.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJBaseViewController.h"

@interface LMJMasonryViewController : LMJBaseViewController

@end
