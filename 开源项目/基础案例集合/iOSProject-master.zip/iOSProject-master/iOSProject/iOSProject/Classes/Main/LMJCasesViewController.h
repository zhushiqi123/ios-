//
//  LMJCasesViewController.h
//  iOSProject
//
//  Created by HuXuPeng on 2018/1/22.
//  Copyright © 2018年 HuXuPeng. All rights reserved.
//

#import "LMJStaticTableViewController.h"

@interface LMJCasesViewController : LMJStaticTableViewController

@end
