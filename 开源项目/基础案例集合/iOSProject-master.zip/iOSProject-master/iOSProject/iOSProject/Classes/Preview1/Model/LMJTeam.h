//
//  LMJTeam.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/4/30.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface LMJTeam : NSObject

/** <#digest#> */
@property (nonatomic, copy) NSString *sortNumber;

/** <#digest#> */
@property (nonatomic, copy) NSString *name;

@end
