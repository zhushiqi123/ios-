
## objective-c 图像化演示5种常见排序算法

### 选择排序
![选择排序](https://github.com/happyte/sort/blob/master/1.gif)

### 冒泡排序
![冒泡排序](https://github.com/happyte/sort/blob/master/2.gif)

### 插入排序
![插入排序](https://github.com/happyte/sort/blob/master/3.gif)

### 快速排序
![快速排序](https://github.com/happyte/sort/blob/master/4.gif)

### 堆排序
![堆排序](https://github.com/happyte/sort/blob/master/5.gif)


