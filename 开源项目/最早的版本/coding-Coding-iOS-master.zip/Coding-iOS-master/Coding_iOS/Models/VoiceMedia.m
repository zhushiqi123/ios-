//
//  VoiceMedia.m
//  Coding_iOS
//
//  Created by sumeng on 8/2/15.
//  Copyright (c) 2015 Coding. All rights reserved.
//

#import "VoiceMedia.h"

@implementation VoiceMedia

@end
