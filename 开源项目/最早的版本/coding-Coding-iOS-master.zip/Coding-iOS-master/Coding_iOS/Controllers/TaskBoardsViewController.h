//
//  TaskBoardsViewController.h
//  Coding_iOS
//
//  Created by Easeeeeeeeee on 2018/4/25.
//  Copyright © 2018年 Coding. All rights reserved.
//

#import "BaseViewController.h"
#import "Project.h"

@interface TaskBoardsViewController : BaseViewController
@property (strong, nonatomic) Project *myProject;
@end
