//
//  ForkTreeViewController.h
//  Coding_iOS
//
//  Created by Ease on 15/9/18.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import "BaseViewController.h"

@interface ForkTreeViewController : BaseViewController
@property (strong, nonatomic) NSString *project_owner_user_name, *project_name;
@end
