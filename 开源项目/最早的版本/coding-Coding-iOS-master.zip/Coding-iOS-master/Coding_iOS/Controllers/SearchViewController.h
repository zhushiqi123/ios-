//
//  SearchViewController.h
//  Coding_iOS
//
//  Created by jwill on 15/11/16.
//  Copyright © 2015年 Coding. All rights reserved.
//

#import "BaseViewController.h"

@interface SearchViewController : BaseViewController

@end
