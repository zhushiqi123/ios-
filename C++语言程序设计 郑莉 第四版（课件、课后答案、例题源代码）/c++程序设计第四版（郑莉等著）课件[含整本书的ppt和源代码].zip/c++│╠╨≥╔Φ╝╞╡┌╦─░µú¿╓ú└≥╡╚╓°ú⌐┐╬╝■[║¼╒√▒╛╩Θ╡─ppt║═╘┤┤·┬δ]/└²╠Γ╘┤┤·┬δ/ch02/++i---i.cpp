#include <iostream>
using namespace std;
void main()
{
	int i=1;
	cout<<" \n "<<i++<<" \n "; 
	cout<<i++<<"\n ";
	cout<<++i<<"\n " ;
	cout<<--i<<"\n " ;
	cout<<i--<<"\n " ;
	cout<<i<<"\n";

}
