//
//  MUSMusicCell.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/9/27.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import "LMJSettingCell.h"

@interface MUSMusicCell : LMJSettingCell

@end
