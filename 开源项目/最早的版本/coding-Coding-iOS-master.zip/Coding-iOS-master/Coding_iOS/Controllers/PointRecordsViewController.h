//
//  PointRecordsViewController.h
//  Coding_iOS
//
//  Created by Ease on 15/8/5.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import "BaseViewController.h"

@interface PointRecordsViewController : BaseViewController

@end
