//2_1.cpp
#include <iostream>
using namespace std;
void main(void)
{
     cout<<"Hello!\n";
     cout<<"Welcome to c++!\n";
}
