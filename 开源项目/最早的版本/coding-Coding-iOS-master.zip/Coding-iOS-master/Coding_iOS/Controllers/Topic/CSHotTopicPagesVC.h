//
//  CSHotTopicPagesVC.h
//  Coding_iOS
//
//  Created by Lambda on 15/8/5.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import "BaseViewController.h"

@interface CSHotTopicPagesVC : BaseViewController


@end

