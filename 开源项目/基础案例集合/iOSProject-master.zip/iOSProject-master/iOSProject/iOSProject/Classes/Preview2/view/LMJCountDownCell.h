//
//  LMJCountDownCell.h
//  PLMMPRJK
//
//  Created by HuXuPeng on 2017/5/5.
//  Copyright © 2017年 GoMePrjk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LMJCountDownModel.h"

@interface LMJCountDownCell : UITableViewCell

/** <#digest#> */
@property (nonatomic, strong) LMJCountDownModel *countDownModel;

@end
