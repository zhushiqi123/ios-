
题目来自 [九度OJ](http://ac.jobdu.com/index.php)



