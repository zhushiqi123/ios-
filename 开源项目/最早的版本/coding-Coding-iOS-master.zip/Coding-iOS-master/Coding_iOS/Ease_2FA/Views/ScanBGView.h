//
//  ScanBGView.h
//  Coding_iOS
//
//  Created by Ease on 15/7/6.
//  Copyright (c) 2015年 Coding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanBGView : UIView
@property (assign, nonatomic) CGRect scanRect;
@end
