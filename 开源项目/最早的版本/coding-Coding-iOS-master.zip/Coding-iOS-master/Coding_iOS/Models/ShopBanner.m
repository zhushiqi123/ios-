//
//  ShopBanner.m
//  Coding_iOS
//
//  Created by liaoyp on 15/11/21.
//  Copyright © 2015年 Coding. All rights reserved.
//

#import "ShopBanner.h"

@implementation ShopBanner

@end
