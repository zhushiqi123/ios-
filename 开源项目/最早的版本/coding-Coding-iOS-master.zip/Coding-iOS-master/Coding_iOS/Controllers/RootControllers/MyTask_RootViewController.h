//
//  MyTask_RootViewController.h
//  Coding_iOS
//
//  Created by 王 原闯 on 14-7-29.
//  Copyright (c) 2014年 Coding. All rights reserved.
//

#import "BaseViewController.h"
#import "Projects.h"
#import "XTSegmentControl.h"
#import "iCarousel.h"
#import "ProjectTaskListView.h"

@interface MyTask_RootViewController : BaseViewController<iCarouselDataSource, iCarouselDelegate>

@end
