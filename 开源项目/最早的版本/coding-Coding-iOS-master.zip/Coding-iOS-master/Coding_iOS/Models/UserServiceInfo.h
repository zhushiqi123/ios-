//
//  ServiceInfo.h
//  Coding_iOS
//
//  Created by Ease on 2016/9/8.
//  Copyright © 2016年 Coding. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserServiceInfo : NSObject
@property (strong, nonatomic) NSNumber *balance, *point_left, *private, *public, *team;
//, *total_memory, *used_memory;

@property (strong, nonatomic) NSString *private_project_quota, *public_project_quota;
@end
