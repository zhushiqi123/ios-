//
//  EACodeReleaseViewController.h
//  Coding_iOS
//
//  Created by Easeeeeeeeee on 2018/3/23.
//  Copyright © 2018年 Coding. All rights reserved.
//

#import "BaseViewController.h"
#import "EACodeRelease.h"

@interface EACodeReleaseViewController : BaseViewController
@property (strong, nonatomic) EACodeRelease *curRelease;
@end
