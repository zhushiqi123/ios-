//
//  SettingAccountViewController.h
//  Coding_iOS
//
//  Created by 王 原闯 on 14-8-26.
//  Copyright (c) 2014年 Coding. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "User.h"

@interface SettingAccountViewController : BaseViewController<UITableViewDataSource, UITableViewDelegate>

@end
