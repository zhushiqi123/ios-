//
//  MCStudent+CoreDataClass.m
//  
//
//  Created by HuXuPeng on 2018/5/3.
//
//

#import "MCStudent+CoreDataClass.h"

@implementation MCStudent

@end
